const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-app.firebaseapp.com",
  projectId: "your-app-id",
  databaseURL: "https://your-app-id.firebaseio.com",
  storageBucket: "your-app.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123def456"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const sounds = {
  eat: new Audio("eat.mp3"),
  poison: new Audio("poison.mp3"),
  bonus: new Audio("bonus.mp3"),
  gameover: new Audio("gameover.mp3")
};

const canvas = document.getElementById("gc");
const ctx = canvas.getContext("2d");

let gs = 20, tc = 20;
let px = 10, py = 10;
let xv = 0, yv = 0;
let trail = [];
let tail = 5;
let apple = {};
let score = 0;
let gameInterval;
let invincible = false;

function startGame() {
  px = py = 10;
  xv = yv = 0;
  trail = [];
  tail = 5;
  score = 0;
  spawnApple();
  updateScore();
  document.getElementById("game-over").style.display = "none";
  gameInterval = setInterval(game, 1000 / 10);
}

function spawnApple() {
  const types = ["normal", "normal", "bonus", "poison"];
  apple.type = types[Math.floor(Math.random() * types.length)];
  apple.x = Math.floor(Math.random() * tc);
  apple.y = Math.floor(Math.random() * tc);
}

function game() {
  px += xv;
  py += yv;
  if (px < 0 || py < 0 || px >= tc || py >= tc) return endGame();

  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle =
    apple.type === "normal" ? "red" :
    apple.type === "bonus" ? "gold" : "purple";
  ctx.fillRect(apple.x * gs, apple.y * gs, gs - 2, gs - 2);

  for (let i = 0; i < trail.length; i++) {
    ctx.fillStyle = "lime";
    ctx.fillRect(trail[i].x * gs, trail[i].y * gs, gs - 2, gs - 2);
    if (trail[i].x === px && trail[i].y === py) {
      if (!invincible) return endGame();
    }
  }

  trail.push({ x: px, y: py });
  while (trail.length > tail) trail.shift();

  if (px === apple.x && py === apple.y) {
    if (apple.type === "normal") {
      tail++;
      score += 1;
      sounds.eat.play();
    } else if (apple.type === "bonus") {
      tail += 3;
      score += 5;
      sounds.bonus.play();
    } else if (apple.type === "poison") {
      tail = Math.max(5, tail - 2);
      score = Math.max(0, score - 3);
      sounds.poison.play();
    }
    updateScore();
    spawnApple();
  }
}

function updateScore() {
  document.getElementById("score-display").textContent = `Score: ${score}`;
}

function endGame() {
  clearInterval(gameInterval);
  sounds.gameover.play();
  document.getElementById("game-over").style.display = "flex";

  const name = document.getElementById("player-name").value || "Anonymous";
  db.ref("leaderboard").push({
    name,
    score,
    date: new Date().toLocaleString()
  });
}

function restartGame() {
  startGame();
}

function shareScore() {
  const msg = `I scored ${score} in Snake Game! 🐍 Play here: ${window.location.href}`;
  if (navigator.share) {
    navigator.share({ title: "Snake Game", text: msg, url: window.location.href });
  } else {
    alert("Copy & share:\n" + msg);
  }
}

function showLeaderboard() {
  db.ref("leaderboard")
    .orderByChild("score")
    .limitToLast(5)
    .once("value", (snapshot) => {
      const list = document.getElementById("scores-list");
      list.innerHTML = "";
      const scores = [];
      snapshot.forEach((child) => scores.push(child.val()));
      scores.reverse().forEach((entry, i) => {
        const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "";
        const li = document.createElement("li");
        li.textContent = `${medal} ${entry.name} – ${entry.score} pts on ${entry.date}`;
        list.appendChild(li);
      });
      document.getElementById("leaderboard").style.display = "flex";
    });
}

function closeLeaderboard() {
  document.getElementById("leaderboard").style.display = "none";
}

document.addEventListener("keydown", function (e) {
  if (e.key === "ArrowLeft") xv = -1, yv = 0;
  if (e.key === "ArrowUp") xv = 0, yv = -1;
  if (e.key === "ArrowRight") xv = 1, yv = 0;
  if (e.key === "ArrowDown") xv = 0, yv = 1;
  if (e.key === "i") invincible = !invincible;
});

startGame();